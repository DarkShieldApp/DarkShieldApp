module.exports = [
"[project]/web/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
}),
];

//# sourceMappingURL=web__next-internal_server_app_page_actions_1xcff7hrp_ev9.js.map