globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/node_modules_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [
    "static/development/_buildManifest.js",
    "static/development/_ssgManifest.js",
    "static/development/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_0fb9-gqu7_t97._.js",
    "static/chunks/1daa_next_dist_compiled_react-dom_cjs_react-dom-client_development_0mp0cp_t-ezj9.js",
    "static/chunks/1q96_modules_next_dist_compiled_react-dom_cjs_react-dom_development_1sqry0_53krp4.js",
    "static/chunks/node_modules_next_dist_compiled_react-dom_0grqycjrj6mju._.js",
    "static/chunks/node_modules_next_dist_compiled_react-server-dom-turbopack_164kp-67asdr9._.js",
    "static/chunks/node_modules_next_dist_compiled_next-devtools_index_090k2jmam7qwg.js",
    "static/chunks/node_modules_next_dist_compiled_1amofcmz--cdp._.js",
    "static/chunks/node_modules_next_dist_client_1165-soo5tfpf._.js",
    "static/chunks/node_modules_next_dist_05y3oi5z9mc_3._.js",
    "static/chunks/node_modules_@swc_helpers_cjs_1r9vbqwj2323d._.js",
    "static/chunks/web_1anvha4rlo79g._.js",
    "static/chunks/turbopack-web_11q0wbt2n0d9y._.js"
  ],
  "rootMainFilesTree": {
    "/page": [
      "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_0fb9-gqu7_t97._.js",
      "static/chunks/1daa_next_dist_compiled_react-dom_cjs_react-dom-client_development_0mp0cp_t-ezj9.js",
      "static/chunks/1q96_modules_next_dist_compiled_react-dom_cjs_react-dom_development_1sqry0_53krp4.js",
      "static/chunks/node_modules_next_dist_compiled_react-dom_0grqycjrj6mju._.js",
      "static/chunks/node_modules_next_dist_compiled_react-server-dom-turbopack_164kp-67asdr9._.js",
      "static/chunks/node_modules_next_dist_compiled_next-devtools_index_090k2jmam7qwg.js",
      "static/chunks/node_modules_next_dist_compiled_1amofcmz--cdp._.js",
      "static/chunks/node_modules_next_dist_client_1165-soo5tfpf._.js",
      "static/chunks/node_modules_next_dist_05y3oi5z9mc_3._.js",
      "static/chunks/node_modules_@swc_helpers_cjs_1r9vbqwj2323d._.js",
      "static/chunks/web_1anvha4rlo79g._.js",
      "static/chunks/turbopack-web_11q0wbt2n0d9y._.js",
      "static/chunks/web_219uq1sj0q91c._.js"
    ]
  },
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
