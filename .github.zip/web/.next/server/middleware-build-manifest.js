globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/Nz9y-4EGqj5YzJMVxDMEW/_buildManifest.js",
    "static/Nz9y-4EGqj5YzJMVxDMEW/_ssgManifest.js",
    "static/Nz9y-4EGqj5YzJMVxDMEW/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0j1we3cwg31qe.js",
    "static/chunks/0m3mby5pxg4oz.js",
    "static/chunks/23e6jep2anmtk.js",
    "static/chunks/turbopack-2u1d16houkiyo.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/0j1we3cwg31qe.js",
        "static/chunks/0m3mby5pxg4oz.js",
        "static/chunks/23e6jep2anmtk.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/0j1we3cwg31qe.js",
        "static/chunks/0m3mby5pxg4oz.js",
        "static/chunks/23e6jep2anmtk.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/0j1we3cwg31qe.js",
        "static/chunks/0m3mby5pxg4oz.js",
        "static/chunks/23e6jep2anmtk.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
